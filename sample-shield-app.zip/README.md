# Sample Shield

Private sample-risk scanner for Elroy and ScoobRoc.

## Vercel Environment Variables

Set these in Vercel:

- ACR_HOST
- ACR_ACCESS_KEY
- ACR_ACCESS_SECRET

## Local development

npm install
npm run dev

## Warning

This is a pre-clearance helper, not legal clearance. It can identify many released recordings through ACRCloud but cannot guarantee 100% detection.
